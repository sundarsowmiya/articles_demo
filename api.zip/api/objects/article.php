<?php
class Article{
 
    // database connection and table article_id
    private $conn;
    private $table_article_id = "article_tbl";
 
    // object properties
    public $article_id	;
    public $article_title;
    public $article_descrip;
    public $article_author_article_id;
    public $article_tags;
    public $article_publish_date;
    public $article_timestamp;
	
    // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }
	// read products
	function read(){	 
		// select all query
		$query = "SELECT * FROM " . $this->table_article_id . "";
	 
		// prepare query statement
		$stmt = $this->conn->prepare($query);
	 
		// execute query
		$stmt->execute();
	 
		return $stmt;
	}
	
	// create product
	function create(){
 
		// query to insert record
		$query = "INSERT INTO
					" . $this->table_article_id . "
				SET
					article_id=:article_id, article_title=:article_title, article_descrip=:article_descrip, article_author_name=:article_author_name, article_tags=:article_tags, article_publish_date=:article_publish_date, article_timestamp=:article_timestamp";
	 
		// prepare query
		$stmt = $this->conn->prepare($query);
	 
		// sanitize
		$this->article_id=htmlspecialchars(strip_tags($this->article_id));
		$this->article_title=htmlspecialchars(strip_tags($this->article_title));
		$this->article_descrip=htmlspecialchars(strip_tags($this->article_descrip));
		$this->article_author_name=htmlspecialchars(strip_tags($this->article_author_name));
		$this->article_tags=htmlspecialchars(strip_tags($this->article_tags));
		$this->article_publish_date=htmlspecialchars(strip_tags($this->article_publish_date));
		$this->article_timestamp=htmlspecialchars(strip_tags($this->article_timestamp));
	 
		// bind values
		$stmt->bindParam(":article_id", $this->article_id);
		$stmt->bindParam(":article_title", $this->article_title);
		$stmt->bindParam(":article_descrip", $this->article_descrip);
		$stmt->bindParam(":article_author_name", $this->article_author_name);
		$stmt->bindParam(":article_tags", $this->article_tags);
		$stmt->bindParam(":article_publish_date", $this->article_publish_date);
		$stmt->bindParam(":article_timestamp", $this->article_timestamp);

		// execute query
		if($stmt->execute()){
			return true;
		}
	 
		return false;
		 
	}
	
	// delete article 
	
	// used when filling up the update product form
	function readOne(){
		// query to read single record
		 $query = "SELECT * 
				FROM " . $this->table_article_id . "
				WHERE
					article_id = ".$this->id. "
				LIMIT
					0,1";
	 
		// prepare query statement
		$stmt = $this->conn->prepare( $query );
	 
		// bind id of product to be updated
		$stmt->bindParam(1, $this->id);
	 
		// execute query
		$stmt->execute();
	 
		// get retrieved row
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		
		// set values to object properties
		$this->article_id= $row['article_id'];
		$this->article_title= $row['article_title'];
		$this->article_descrip= $row['article_descrip'];
		$this->article_author_name=$row['article_author_name'];
		$this->article_tags=$row['article_tags'];
		$this->article_publish_date=$row['article_publish_date'];
		$this->article_timestamp=$row['article_timestamp'];			
	}
	
	// update the product
	function update(){	 
		// update query
	
		 $query = "UPDATE
					" . $this->table_article_id . "
				SET
					article_title = :article_title,
					article_descrip = :article_descrip,
					article_author_name = :article_author_name,
					article_tags = :article_tags,
					article_publish_date = :article_publish_date
					
				WHERE
					article_id = :article_id";

		// prepare query statement
		$stmt = $this->conn->prepare($query);
	 
		// sanitize
		$this->article_id=htmlspecialchars(strip_tags($this->article_id));
		$this->article_title=htmlspecialchars(strip_tags($this->article_title));
		$this->article_descrip=htmlspecialchars(strip_tags($this->article_descrip));
		$this->article_author_name=htmlspecialchars(strip_tags($this->article_author_name));
		$this->article_tags=htmlspecialchars(strip_tags($this->article_tags));
		$this->article_publish_date=htmlspecialchars(strip_tags($this->article_publish_date));
		
	 
		// bind values
		$stmt->bindParam(":article_id", $this->article_id);
		$stmt->bindParam(":article_title", $this->article_title);
		$stmt->bindParam(":article_descrip", $this->article_descrip);
		$stmt->bindParam(":article_author_name", $this->article_author_name);
		$stmt->bindParam(":article_tags", $this->article_tags);
		$stmt->bindParam(":article_publish_date", $this->article_publish_date);
	
		
	 
		// execute the query
		if($stmt->execute()){
			return true;
		}
	 
		return false;
	}
	
	// delete the product
	function delete(){
	 
		// delete query
		$query = "DELETE FROM " . $this->table_article_id . " WHERE article_id = ".$this->id;
	 
		// prepare query
		$stmt = $this->conn->prepare($query);
	 
		// sanitize
		$this->id=htmlspecialchars(strip_tags($this->id));
	 
		// bind id of record to delete
		$stmt->bindParam(1, $this->id);
	 
		// execute query
		if($stmt->execute()){
			return true;
		}
	 
		return false;
		 
	}
}
?>


