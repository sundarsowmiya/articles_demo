<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
// database connection will be here

// include database and object files
include_once '../config/database.php';
include_once '../objects/article.php';
 
// instantiate database and article object
$database = new Database();
$db = $database->getConnection();
 
// initialize object
$article = new Article($db);
 
// read articles will be here


// query articles
$stmt = $article->read();
$num = $stmt->rowCount();

// check if more than 0 record found
if($num>0){ 
    // articles array
    $articles_arr=array();
    $articles_arr["records"]=array();
 
    // retrieve our table contents
    // fetch() is faster than fetchAll()
    // http://stackoverflow.com/questions/2770630/pdofetchall-vs-pdofetch-in-a-loop
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        // extract row
        // this will make $row['name'] to
        // just $name only
        extract($row);
        $article_item=array(
            "article_id" => $article_id,
            "article_title" => $article_title,
            "article_descrip" => html_entity_decode($article_descrip),
            "article_author_name" => $article_author_name,
            "article_tag" => $article_tags,
            "article_publish_date" => $article_publish_date,
            "article_timestamp" => $article_timestamp
        );
	
        array_push($articles_arr["records"], $article_item);
    }
 
    // set response code - 200 OK
    http_response_code(200);
 
    // show articles data in json format
    echo json_encode($articles_arr);
}
else{ 
    // set response code - 404 Not found
    http_response_code(404);
 
    // tell the user no articles found
    echo json_encode(
        array("message" => "No articles found.")
    );
}

