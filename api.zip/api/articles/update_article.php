<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
// include database and object files
include_once '../config/database.php';
include_once '../objects/article.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare article object
$article = new Article($db);
 
// get id of article to be edited
$data = json_decode(file_get_contents("php://input"));
 
// set ID property of article to be edited
$article->article_id = $data->article_id;
 
// set article property values

$article->article_title = $data->article_title;
$article->article_descrip = $data->article_descrip;
$article->article_author_name = $data->article_author_name;
$article->article_tags = $data->article_tags;

 $article_publish_date = new DateTime($data->article_publish_date);
 
  
$article->article_publish_date = $article_publish_date->format('Y-m-d');
//$article->article_publish_date = date("m/d/Y", $article->article_publish_date);
//$article_publish_date = new DateTime($date);



//echo $article->article_publish_date->format('d-m-Y');


// update the article
if($article->update()){
 
    // set response code - 200 ok
    http_response_code(200);
 
    // tell the user
    echo json_encode(array("message" => "Article was updated."));
}
 
// if unable to update the article, tell the user
else{
 
    // set response code - 503 service unavailable
    http_response_code(503);
 
    // tell the user
    echo json_encode(array("message" => "Unable to update article."));
}
?>