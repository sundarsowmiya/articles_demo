<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
 
// include database and object files
include_once '../config/database.php';
include_once '../objects/article.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare article object
$article = new Article($db);
 
// set id property of record to read
$article->id = isset($_GET['id']) ? $_GET['id'] : die();
// read the details of article to be edited
$article->readOne();

if($article->article_title != null){
    // create array
    $article_arr = array(
		"article_id" => $article-> article_id,
		"article_title" => $article-> article_title,
		"article_descrip" => $article-> article_descrip,
		"article_author_name" => $article-> article_author_name,
		"article_tags" => $article-> article_tags,
		"article_publish_date" => $article-> article_publish_date,
		"article_timestamp" => $article-> article_timestamp
    );
 
    // set response code - 200 OK
    http_response_code(200);
 
    // make it json format
    echo json_encode($article_arr);
}
 
else{
    // set response code - 404 Not found
    http_response_code(404);
 
    // tell the user article does not exist
    echo json_encode(array("message" => "Article does not exist."));
}
?>