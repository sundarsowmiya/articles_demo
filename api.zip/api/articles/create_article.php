<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
// get database connection
include_once '../config/database.php';
 
// instantiate article object
include_once '../objects/article.php';
 
$database = new Database();
$db = $database->getConnection();
 
$article = new Article($db);
 
// get posted data
$data = json_decode(file_get_contents("php://input"));
 
// make sure data is not empty
if(
    !empty($data->article_id) &&
    !empty($data->article_title) &&
    !empty($data->article_descrip) &&
    !empty($data->article_author_name) &&
    !empty($data->article_tag)
){		
    // set article property values
    $article->article_id = $data->article_id;
    $article->article_title = $data->article_title;
    $article->article_descrip = $data->article_descrip;
    $article->article_author_name = $data->article_author_name;
    $article->article_tags = $data->article_tag;
   // $article->article_publish_date = $data->article_publish_date;
	$article_publish_date = new DateTime($data->article_publish_date);
	$article->article_publish_date = $article_publish_date->format('Y-m-d');

    $article->article_timestamp = date('Y-m-d H:i:s');
 
    // create the article
    if($article->create()){
 
        // set response code - 201 created
        http_response_code(201);
 
        // tell the user
        echo json_encode(array("message" => "Article was created."));
    }
 
    // if unable to create the article, tell the user
    else{
 
        // set response code - 503 service unavailable
        http_response_code(503);
 
        // tell the user
        echo json_encode(array("message" => "Unable to create article."));
    }
}
 
// tell the user data is incomplete
else{
 
    // set response code - 400 bad request
    http_response_code(400);
 
    // tell the user
    echo json_encode(array("message" => "Unable to create article. Data is incomplete."));
}
?>